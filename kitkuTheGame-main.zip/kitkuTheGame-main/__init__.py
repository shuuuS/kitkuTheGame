import json

from characters.tofik import Tofik
from characters.kropcia import Kropcia

class Game():
    main_character = Tofik()
    enemy1_character = Kropcia(12, 10, 1)
    def __init__(self):
        pass
    
if __name__ == "__main__":
    Game()

turn = 0
while True:
        action = input("What do you want do?\n 1) Activitis \n 2) option \n 3) Exit\n")
        if action == "1" and (turn % 2 == 0):
            option = input("\n1) Move\n2) Meow\n3) Rest\n")
            
            if option == "1":
                Game().main_character.movement()
                turn += 1
            if option == "2":
                Game().main_character.abilites()
                turn += 1
            if option == "3":
                Game().main_character.rest()
                turn += 1
        elif turn % 2 == 1:
            Game().enemy1_character.abilities()
            turn += 1

        print(f"Turn: {turn}")
        if action == "2":
            option = input("\n1) Check stats\n 2)....\n")
        if option == "1":
            Game().main_character.showStats()
        if action == "3":
            break




        
        


    



