import random

class Kropcia():
    def __init__(self, hp, energy, lvl):
        self.hp = hp
        self.energy = energy
        self.lvl = lvl

        self.hp = self.hp**self.lvl
        self.energy = self.energy*lvl*0.4

    def showStats(self):
        print(f"Kropcia\n hp:{self.hp}\n energy:{self.energy}\n lvl:{self.lvl}\n")

    def abilities(self):
        
        print("Kropcia tried attack D: ")
    
        