
class StatsPerLevel():
    def __init__(self, expPoints, levels):
        pass
    
    def gainingStats(self):
        pass
